/*
 * Class: CMSC203 
 * Instructor:Ashique Tanveer
 * Description: (Give a brief description for each Class)
 * Due: 03/28/2024
 * Platform/compiler:Eclips
 * I pledge that I have completed the programming 
 * assignment independently. I have not copied the code 
 * from a student or any source. I have not given my code 
 * to any student.
   Print your Name here: Zemariam K HafteGebriel__________
*/

public class ManagementCompany {
	int MAX_PROPERTY = 5;
	int MGMT_WIDTH = 10;
	int MGMT_DEPTH = 10;

	// Variables
	private String Name = "";
	private String TaxID = "";
	private double ManagementFee = 0.00;
	private Plot ManagementPlot;
	private Property Properties[] = new Property[MAX_PROPERTY];
	private int currentPropertyIndex = -1; 

	public ManagementCompany() {
		this.ManagementPlot = new Plot(0, 0, MGMT_WIDTH, MGMT_DEPTH);
	}

	public ManagementCompany(String n, String tid, double mfee) {
		this.Name = n;
		this.TaxID = tid;
		this.ManagementFee = mfee;
		this.ManagementPlot = new Plot(0, 0, MGMT_WIDTH, MGMT_DEPTH);
	}

	public ManagementCompany(String n, String tid, double mfee, int x, int y, int w, int d) {
		this.Name = n;
		this.TaxID = tid;
		this.ManagementFee = mfee;
		this.ManagementPlot = new Plot(x, y, w, d);
	}

	public int getMAX_PROPERTY() {
		return this.MAX_PROPERTY;
	}

	public Plot getPlot() { return this.ManagementPlot; }

	public String getName() { return this.Name; }

	public double totalRent() {
		// Variables
		double total = 0;

		// Loop
		for (int i = 0; i < this.Properties.length; i++) {
			// Checks
			if (this.Properties[i] == null) { continue; }

			// Variables
			Property p = this.Properties[i];
			total += p.getRentAmount();
		}

		// Return
		return (this.Properties.length > 0 ? total : 0.00);
	}

	public String maxRentPropInfo() {
		// Variables
		double highest = 0;
		String stringified = "";

		// Loop
		for (int i = 0; i < this.Properties.length; i++) {
			// Variables
			Property p = this.Properties[i];

			if (p == null) { continue; }
			if (p.getRentAmount() > highest) {
				highest = p.getRentAmount();
				stringified = p.toString();
			}
		}


		// Return
		return (highest > 0 ? stringified : "");
	}

// assignment requested functions 
	public int addProperty(Property P) {
		// Variables
		int index = currentPropertyIndex;
		int newIndex = currentPropertyIndex + 1;

		// Checks
		if (newIndex >= this.MAX_PROPERTY) { return -1; }

		// Variables
		this.Properties[newIndex] = new Property(P);

		// Default
		currentPropertyIndex = newIndex;
		return newIndex;
	}

	public int addProperty(String n, String c, double r, String o) {
		// Variables
		int index = currentPropertyIndex;
		int newIndex = currentPropertyIndex + 1;

		// Checks
		if (newIndex >= this.MAX_PROPERTY) { return -1; }

		// Variables
		this.Properties[newIndex] = new Property(n, c, r, o);

		// Default
		currentPropertyIndex = newIndex;
		return newIndex;
	}

	public int addProperty(String n, String c, double r, String o, int x, int y, int w, int d) {
		// Variables
		int index = currentPropertyIndex;
		int newIndex = currentPropertyIndex + 1;
		Plot tempPlot = new Plot(x, y, w, d);

		// Checks
		if (newIndex >= this.MAX_PROPERTY) { return -1; }
		if (this.ManagementPlot.encompasses(tempPlot) == false) { return -3; }
		if (index >= 0) {
			for (int i = 0; i < this.Properties.length; i++) {
				// Checks
				if (this.Properties[i] == null) { continue; }
				if (this.Properties[i].getPlot().overlaps(tempPlot) == true) { return -4; }
			}
		}

		// Variables
		this.Properties[newIndex] = new Property(n, c, r, o, x, y, w, d);

		// Default
		currentPropertyIndex = newIndex;
		return newIndex;
	}
	
	public double getTotalRent() {
	    double totalRent = 0;
	    for (int i = 0; i <= currentPropertyIndex; i++) {
	        totalRent += Properties[i].getRentAmount();
	    }
	    return totalRent;
	}
	
	public Property getHighestRentPropperty() {
	    // Variables
	    double highest = 0;
	    Property highestRentProperty = null;

	    // Loop
	    for (int i = 0; i < this.Properties.length; i++) {
	        // Variables
	        Property p = this.Properties[i];

	        if (p == null) { continue; }
	        if (p.getRentAmount() > highest) {
	            highest = p.getRentAmount();
	            highestRentProperty = p;
	        }
	    }

	    return highestRentProperty;
	}
	
	public void removeLastProperty() {
	    if (currentPropertyIndex >= 0) {
	        Properties[currentPropertyIndex] = null;
	        currentPropertyIndex--;
	    }
	}
	
	public boolean isPropertiesFull() {
	    return currentPropertyIndex == MAX_PROPERTY - 1;
	}
	
	public int getPropertiesCount() {
	    return currentPropertyIndex + 1;
	}
	
	public boolean isManagementFeeValid() {
	    return ManagementFee >= 0 && ManagementFee <= 100;
	}
	
	public String toString() {
	    StringBuilder result = new StringBuilder("List of the properties for " + getName() + ", taxID: " + TaxID + "\n");
	    result.append("______________________________________________________\n");

	    for (int i = 0; i <= currentPropertyIndex; i++) {
	        result.append(Properties[i].toString()).append("\n");
	    }

	    result.append("______________________________________________________\n"); 
	    result.append(" total management Fee: ").append(totalRent() * (ManagementFee * 0.01)).append("\n");

	    return result.toString();
	}

}