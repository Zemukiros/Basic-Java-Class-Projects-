/*
 * Class: CMSC203 
 * Instructor:Ashique Tanveer
 * Description: (Give a brief description for each Class)
 * Due: 03/28/2024
 * Platform/compiler:Eclips
 * I pledge that I have completed the programming 
 * assignment independently. I have not copied the code 
 * from a student or any source. I have not given my code 
 * to any student.
   Print your Name here: Zemariam K HafteGebriel__________
*/

// Created based on the Plot javadoc provided by the assignment 

public class Plot {
	// Variables
	private int PlotX = 0;
	private int PlotY = 0;
	private int PlotW = 0;
	private int PlotD = 0;

// constructors 
	public Plot() {
		this.PlotW = 1;
		this.PlotD = 1;
	}
	
	public Plot(int X, int Y, int W, int D) {
		this.PlotX = X;
		this.PlotY = Y;
		this.PlotW = W;
		this.PlotD = D;
	}

// getters
	public int getX() { return this.PlotX; }


	public int getY() { return this.PlotY; }


	public int getWidth() { return this.PlotW; }

	public int getDepth() { return this.PlotD; }

//setters
	public void setX(int X) { this.PlotX = X; }

	public void setY(int Y) { this.PlotY = Y; }

	public void setWidth(int W) { this.PlotW = W; }

	public void setDepth(int D) { this.PlotD = D; }

// checking it this plot overlaps with another plot 
	public boolean overlaps(Plot P) {
		// Variables
		int result = 0;
		int p1x1 = this.getX(); 
		int p2x1 = P.getX();
		int p1x2 = this.getX() + this.getWidth(); 
		int p1y1 = this.getY(); 
		int p2y1 = P.getY();
		int p1y2 = this.getY() + this.getDepth(); 

		// checking
		if (p1x1 >= p2x1 || p2x1 <= p1x2) { result = 1; }
		if (p1y1 >= p2y1 || p2y1 <= p1y2) { result = 1; }
		
		if (result == 0) {
			return false;
		} else {
			return true;
		}
		
	}

// check if it is inside of the area it's supposed to be in 
	public boolean encompasses(Plot P) {
		int result = 0;
		int p1x1 = this.getX(); 
		int p2x1 = P.getX();
		int p1x2 = this.getX() + this.getWidth(); 
		int p1y1 = this.getY();
		int p2y1 = P.getY();
		int p1y2 = this.getY() + this.getDepth(); 

		// checking
		if (p1x1 + this.getWidth() > p2x1) { result = 1; }
		if (p1y1 + this.getDepth() > p2y1) { result = 1; }
		if (p1x1 >= p2x1 || p2x1 <= p1x2) { result = 1; }
		if (p1y1 >= p2y1 || p2y1 <= p1y2) { result = 1; }

		System.out.println("Encompasses: this.X" + p1x1 + " P.X " + p2x1);

		if (result == 0) {
			return false;
		} else {
			return true;
		}
	}

//toString 
	
  public String toString() {
		
		String r = "";

		
		r += this.getX() + "," + this.getY() + ",";
		r +=  this.getWidth() + ",";
		r +=  this.getDepth();

		
		return r;
	}
}