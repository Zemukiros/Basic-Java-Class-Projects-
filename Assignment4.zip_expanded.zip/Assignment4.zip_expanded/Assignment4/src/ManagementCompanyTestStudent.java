import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class ManagementCompanyTestStudent {
    private ManagementCompany company;
    private Property property1, property2, property3;

    @Before
    public void setUp() throws Exception {
        company = new ManagementCompany("ABC Management", "12345", 10.0);
        property1 = new Property("Cozy Apartment", "New York", 1500.0, "John Doe");
        property2 = new Property("Luxury Villa", "Los Angeles", 5000.0, "Alice Smith", 10, 20, 100, 150);
        property3 = new Property("Beach House", "Miami", 3000.0, "Bob Johnson");

        company.addProperty(property1);
        company.addProperty(property2);
    }

    @After
    public void tearDown() throws Exception {
        company = null;
        property1 = null;
        property2 = null;
        property3 = null;
    }

    @Test
    public void testGetMAX_PROPERTY() {
        assertEquals(5, company.getMAX_PROPERTY());
    }

    @Test
    public void testGetPlot() {
        assertEquals(new Plot(0, 0, 10, 10), company.getPlot());
    }

    @Test
    public void testGetName() {
        assertEquals("ABC Management", company.getName());
    }

    @Test
    public void testTotalRent() {
        assertEquals(6500.0, company.totalRent(), 0.001);
    }

    @Test
    public void testMaxRentPropInfo() {
        assertEquals("Luxury Villa,Los Angeles,Alice Smith,5000.0", company.maxRentPropInfo());
    }

    @Test
    public void testAddProperty() {
        assertEquals(2, company.addProperty(property3));
    }

    @Test
    public void testGetTotalRent() {
        assertEquals(9500.0, company.getTotalRent(), 0.001);
    }

    @Test
    public void testGetHighestRentProperty() {
        assertEquals("Luxury Villa,Los Angeles,Alice Smith,5000.0", company.getHighestRentPropperty().toString());
    }

    @Test
    public void testRemoveLastProperty() {
        company.removeLastProperty();
        assertEquals(1, company.getPropertiesCount());
    }

    @Test
    public void testIsPropertiesFull() {
        assertFalse(company.isPropertiesFull());
    }

    @Test
    public void testGetPropertiesCount() {
        assertEquals(2, company.getPropertiesCount());
    }

    @Test
    public void testIsManagementFeeValid() {
        assertTrue(company.isManagementFeeValid());
    }

    @Test
    public void testToString() {
        String expected = "List of the properties for ABC Management, taxID: 12345\n" +
                "______________________________________________________\n" +
                "Cozy Apartment,New York,John Doe,1500.0\n" +
                "Luxury Villa,Los Angeles,Alice Smith,5000.0 \n" +
                "______________________________________________________\n" +
                " total management Fee: 156.78";

        assertEquals(expected, company.toString());
    }
}
