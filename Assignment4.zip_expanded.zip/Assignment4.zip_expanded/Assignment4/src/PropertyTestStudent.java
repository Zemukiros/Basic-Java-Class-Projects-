import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class PropertyTestStudent {
    @SuppressWarnings("unused")
	private Property property1, property2, property3;

    @Before
    public void setUp() throws Exception {
        property1 = new Property("Cozy Apartment", "New York", 1500.0, "John Doe");
        property2 = new Property("Luxury Villa", "Los Angeles", 5000.0, "Alice Smith", 10, 20, 100, 150);
        property3 = new Property(property2);
    }

    @After
    public void tearDown() throws Exception {
        property1 = null;
        property2 = null;
        property3 = null;
    }

    @Test
    public void testGetCity() {
        assertEquals("New York", property1.getCity());
    }

    @Test
    public void testGetOwner() {
        assertEquals("John Doe", property1.getOwner());
    }

    @Test
    public void testGetPlot() {
        assertEquals(new Plot(0, 0,0,0), property1.getPlot());
    }

    @Test
    public void testGetPropertyName() {
        assertEquals("Cozy Apartment", property1.getPropertyName());
    }

    @Test
    public void testGetRentAmount() {
        assertEquals(1500.0, property1.getRentAmount(), 0.001);
    }

    @Test
    public void testSetCity() {
        property1.setCity("Chicago");
        assertEquals("Chicago", property1.getCity());
    }

    @Test
    public void testSetOwner() {
        property1.setOwner("Mary Johnson");
        assertEquals("Mary Johnson", property1.getOwner());
    }

    @Test
    public void testSetPropertyName() {
        property1.setPropertyName("Small Studio");
        assertEquals("Small Studio", property1.getPropertyName());
    }

    @Test
    public void testSetRentAmount() {
        property1.setRentAmount(800.0);
        assertEquals(800.0, property1.getRentAmount(), 0.001);
    }

    @Test
    public void testToString() {
        String expected = "Cozy Apartment,New York,John Doe,1500.0";
        assertEquals(expected, property1.toString());
    }
}
