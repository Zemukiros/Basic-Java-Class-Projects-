
public class MyLauncher {
    public static void main(String[] args){
    	MgmCompanyGui.main(args);
    }
} 
