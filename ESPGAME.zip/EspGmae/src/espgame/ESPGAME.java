/*
 * Class: CMSC203 
 * Instructor: Ashique Tanveer 
 * Description: (Give a brief description for each Class)
 * Due: 2/12/2024
 * Platform/compiler: ECLIPS
 * I pledge that I have completed the programming assignment 
* independently. I have not copied the code from a student or   * any source. I have not given my code to any student.
 * Print your Name here: __Z.K.H________
*/

package espgame;
import java.util.Random;
import java.util.Scanner;

// This is a simple program that test ESP skill by guessing colors. 

public class ESPGAME{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Random random = new Random();
        String[] colors = {"Red", "Green", "Blue", "Orange", "Yellow", "Black", "White"};
        
        // Asking the user for their name
        System.out.print("Whats your name: ");
        String name = scanner.nextLine();
         
        //Asking them to describe themselves
        System.out.print("Describe yourself: ");
        String description = scanner.nextLine();
        
         
        // Getting the due date
        System.out.print("Due Date: ");
        String number = scanner.nextLine();
        
      
        System.out.print(" CMSC203 Assignment1: Test your ESP skills!\n\n\n");
        
        
        int correctGuesses = 0;
        
        // for loop for guessing colors
        for (int i = 0; i < 11; i++) {
            int randomNumber = random.nextInt(colors.length);
            String selectedColor = colors[randomNumber];
            
           // Asking the user for their guess
            System.out.print(" \n I am thinking of a color.\r\n"
            		+ " Is it Red, Green, Blue, Orange, Yellow, Black,or White\r\n"
            		+ " Enter your guess: ");
            	
            String userGuess = scanner.nextLine();
            
            // displaying the color
            System.out.println(" \n I was thinking of " + selectedColor );
            
            // finding out if the gusse was correct
            if (userGuess.equalsIgnoreCase(selectedColor)) {
                correctGuesses++;
            }
        }
        
       // displaying the result
        System.out.println("\nYou guessed " + correctGuesses + " out of 11 colors correctly");
        System.out.println("Student Name: " + name); 
        System.out.println("User Description: " + description);
        System.out.println("Due Date: " + number );
        
        scanner.close();
    }
}


