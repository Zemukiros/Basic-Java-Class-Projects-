package task;

import java.util.Scanner;

public class Movie {
	 public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);

	        Movie movie = new Movie();

	        System.out.println("Enter the title of a movie: ");
	        String title = scanner.nextLine();
	        movie.setTitle(title);

	        System.out.println("Enter the movie's rating: ");
	        String rating = scanner.nextLine();
	        movie.setRating(rating);

	        System.out.println("Enter the number of tickets sold for this movie: ");
	        int ticketsSold = scanner.nextInt();
	        movie.setSoldTickets(ticketsSold);

	        System.out.println(movie.toString());

	        scanner.close();
	    }

	private void setTitle(String title) {
		// TODO Auto-generated method stub
		
	}

	private void setSoldTickets(int ticketsSold) {
		// TODO Auto-generated method stub
		
	}

	private void setRating(String rating) {
		// TODO Auto-generated method stub
		
	}

}
