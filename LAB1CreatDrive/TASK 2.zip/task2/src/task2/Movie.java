package task2;

public class Movie {

	public void setTitle(String title) {
		// TODO Auto-generated method stub
		
	}

	public void setRating(String rating) {
		// TODO Auto-generated method stub
		
	}

	public void setSoldTickets(int ticketsSold) {
		// TODO Auto-generated method stub
		
	}

}
