import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class CryptoManagerTestStudent {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testStringInBounds() {
		assertTrue(CryptoManager.isStringInBounds("YO YO WHATS UP"));
	}

	@Test
	public void testEncryptCaesar() {
		assertEquals("Ejrfwnfr", CryptoManager.caesarEncryption("Zemariam", 7));
	}

	@Test
	public void testDecryptCaesar() {
		
		assertEquals(">ck_pg_k", CryptoManager.caesarDecryption("Ejrfwnfr", 7));
	}
	
	@Test
	public void testEncryptBellaso() {
		
		assertEquals("2KE=3(X>:47L=", CryptoManager.bellasoEncryption("dCode Bellaso", "NHVY"));
	}
	
	@Test
	public void testDecryptBellaso() {
		System.out.println(CryptoManager.bellasoDecryption("UJ^^((HT^X[YYM\"", "HELLO"));
		assertEquals("MERRY CHRISTMAS", CryptoManager.bellasoDecryption("UJ^^((HT^X[YYM\"", "HELLO"));
	}
	}

