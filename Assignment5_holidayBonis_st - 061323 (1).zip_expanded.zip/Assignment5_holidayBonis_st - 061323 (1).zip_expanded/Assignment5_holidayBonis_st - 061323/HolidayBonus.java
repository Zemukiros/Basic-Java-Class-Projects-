public class HolidayBonus {
    // Constants
    public static final double BONUS_HIGHEST_STORE = 5000.0; 
    public static final double BONUS_LOWEST_STORE = 1000.0;   
    public static final double BONUS_OTHER_STORES = 2000.0;   

    public static double[] calculateHolidayBonus(double[][] data) {
    	double[][] bonusArray = new double[data.length][];
        double[] holidayBonuses = new double[data.length];
        
        for (int i = 0; i < data.length; i++) {
        	bonusArray[i] = new double[data[i].length];
            for (int j = 0; j < data[i].length; j++) {
                if (data[i][j] == TwoDimRaggedArrayUtility.getHighestInColumn(data, j)) {
                    bonusArray[i][j] += BONUS_HIGHEST_STORE;
                } 
                if (data[i][j] == TwoDimRaggedArrayUtility.getLowestInColumn(data, j)) {
                	bonusArray[i][j]  += BONUS_LOWEST_STORE;
                } 
                if(data[i][j] != TwoDimRaggedArrayUtility.getHighestInColumn(data, j) && data[i][j] != TwoDimRaggedArrayUtility.getLowestInColumn(data, j)){
                	bonusArray[i][j] += BONUS_OTHER_STORES;
                }
            }
        }
        for (int i = 0; i < bonusArray.length; i++) {
        	double total = 0;
        	for(int j = 0; j < bonusArray[i].length; j++) {
        		total +=bonusArray[i][j];
        	}
        	holidayBonuses[i] += total; // why 
        }
        return holidayBonuses;
    }

    public static double calculateTotalHolidayBonus(double[][] data) {
        double total  = 0;
        double[] temp = calculateHolidayBonus(data);
        for(int i = 0; i < data.length; i++) {
        	total += temp[i];
        }
        return total; 
    }
}