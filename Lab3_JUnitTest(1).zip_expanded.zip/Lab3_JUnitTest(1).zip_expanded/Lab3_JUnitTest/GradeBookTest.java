import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;


public class GradeBookTest {
	
	    GradeBook myGradeBook1, myGradeBook2;
		
	    @BeforeEach
	    void setUp() throws Exception {
	        myGradeBook1 = new GradeBook(5);
	        myGradeBook2 = new GradeBook(5);
			
	        myGradeBook1.addScore(85);
	        myGradeBook1.addScore(77);
	        myGradeBook1.addScore(32);
	        myGradeBook2.addScore(91);
	        myGradeBook2.addScore(74);	
	    }

	    @AfterEach
	    void tearDown() throws Exception {
	        myGradeBook1 = null;
	        myGradeBook2 = null;
	    }

	    @Test
	    void testAddScore() {}

	    @Test
	    void testSum() {
	        assertTrue(194.0 == myGradeBook1.sum());
	        assertTrue(165.0 == myGradeBook2.sum());
	    }

	    @Test
	    void testMinimum() {
	        assertTrue(32.0 == myGradeBook1.minimum());
	        assertTrue(74.0 == myGradeBook2.minimum());
	    }

	    @Test
	    void testFinalScore() {
	        assertTrue(162.0 == myGradeBook1.finalScore());
	        assertTrue(91.0 == myGradeBook2.finalScore());	
	    }

	    @Test
	    void testGetScoreSize() {
	        assertEquals(3, myGradeBook1.getScoreSize());
	        assertEquals(2, myGradeBook2.getScoreSize());
	    }

	    @Test
	    void testToString() {
	        assertTrue("85.0 77.0 32.0".equals(myGradeBook1.toString()));
	        assertTrue("91.0 74.0".equals(myGradeBook2.toString()));
	    }
	}
	
