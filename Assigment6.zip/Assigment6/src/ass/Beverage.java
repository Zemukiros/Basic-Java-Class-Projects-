package ass;
/*
 * Class: CMSC203 
 * Instructor: 
 * Description: (Give a brief description for each Class)
 * Due: 5/3/2024
 * Platform/compiler: clips
 * I pledge that I have completed the programming  
 * assignment independently. I have not copied the code 
 * from a student or any source. I have not given my code 
 * to any student.
   Print your Name here: __Zemariam K   haftegebriel________
*/

public abstract class Beverage {

	private String name;
	private Type type;
	private Size size;
	private   double PRICE = 2.0;
	private final double SIZE_UP = 1.0;



public Beverage(String n, Type coffee, Size s) {
	name = n;
	type = coffee;
	size = s;
}
public abstract double calcPrice();

public String getBevName() {
	return name;
}

public void setName(String n) {
	name = n;
}

public Type getType() {
	return type;
}

public void setType(Type t) {
	type = t;
}

public Size getSize() {
	return size;
}

public void setSize(Size s) {
	size = s;
}

public double getBasePrice() {
	return PRICE;
}

public double getSizeUp() {
	return SIZE_UP;
}

public String toString() {
	return name + ", " + size;
	
}


/// ask help
public void addSizePrice() {
    if (size.equals("medium") || size.equals("large")) {
       PRICE += SIZE_UP;
    }
}
public boolean equals(Beverage beverage) {
	if(name.equals(beverage.getBevName())) {
		if (size == beverage.getSize() && type == beverage.getType()) 
				return true;
	}
	return false;	
}

}
