package ass;

/*
 * Class: CMSC203 
 * Instructor: 
 * Description: (Give a brief description for each Class)
 * Due: 5/3/2024
 * Platform/compiler: elips
 * I pledge that I have completed the programming  
 * assignment independently. I have not copied the code 
 * from a student or any source. I have not given my code 
 * to any student.
   Print your Name here: __Zemariam K   haftegebriel________
*/

public class Alcohol extends Beverage{
	private boolean isWeekend;
	private final double WEEKEND_PRICE = 0.6;
	
	
	public Alcohol(String name, Size size, boolean isWeekend) {
	    super(name, Type.ALCOHOL, size);
	    this.isWeekend = isWeekend;
	}
	
	public boolean isWeekend() {
	    return isWeekend;
	}

	public void setWeekend(boolean isWeekend) {
	    this.isWeekend = isWeekend;
	}

	public double getWeekendPrice() {
	    return WEEKEND_PRICE;
	}

	public String toString() {
	    String str = "" + getBevName() + ", " + getSize();
	    double price = 0.0;
	    boolean weekendFlag = isWeekend;
	    if (weekendFlag) 
	        str += ", weekend fee";
	    price = calcPrice();
	    str += ", price: $" + price;
	    return str;
	}
	
	public boolean equals(Alcohol a) {
	    boolean baseEquals = super.equals(a);
	    if (baseEquals && isWeekend == a.isWeekend())
	        return true;
	    return false;
	}
	
	public double calcPrice() {
	    double price = super.getBasePrice();
	    boolean weekendFlag = isWeekend;

	    if (super.getSize() == Size.MEDIUM)
	        price += super.getSizeUp();
	    else if (super.getSize() == Size.LARGE)
	        price += 2 * super.getSizeUp();

	    if (weekendFlag)
	        price += WEEKEND_PRICE;

	    return price;
	}
}
