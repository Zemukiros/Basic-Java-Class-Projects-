package ass;

public enum Type {COFFEE, SMOOTHIE, ALCOHOL;

}
