package ass;

public enum Size {SMALL, MEDIUM, LARGE;

}
