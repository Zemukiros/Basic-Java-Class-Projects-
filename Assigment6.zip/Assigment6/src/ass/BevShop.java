package ass;
import java.util.*;

public class BevShop implements BevShopInterface {
	 
	  private int alcoholOrderCount;
	    private final int MIN_AGE_FOR_ALCOHOL = 21;
	    private final int MAX_ORDER_FOR_ALCOHOL = 3;
	    private final int MIN_TIME = 8;
	    private final int MAX_TIME = 23;
	    private final int MAX_FRUIT = 5;
	    private int currentIndex;
	    private ArrayList<Order> orderList;
			
	    
	  public BevShop() {
	        orderList = new ArrayList<>();
	    }
	   
	  @Override  
	 public boolean isValidTime(int time) { //
	        return time >= MIN_TIME && time <= MAX_TIME;
	    }
	  
	  @Override
	  public int getMaxNumOfFruits() {
		  return MAX_FRUIT; 
	  }
	 
	  @Override
	 public int getMinAgeForAlcohol() {//
	        return MIN_AGE_FOR_ALCOHOL;
	    }
	 
	 @Override
	 public boolean isMaxFruit(int numOfFruits) { //
	        return numOfFruits > MAX_FRUIT;
	    }
	 @Override
	 public int getMaxOrderForAlcohol() {
	        return MAX_ORDER_FOR_ALCOHOL;
	    }
	 
	    	
	 @Override  
	 public boolean isEligibleForMore() {//
	        return alcoholOrderCount < 3;
	    }
	 
	 @Override
	 public int getNumOfAlcoholDrink() { //
	        return alcoholOrderCount;
	    }
	 
	 @Override
	 public boolean isValidAge(int age) { //
	        return age >= MIN_AGE_FOR_ALCOHOL;
	        
	    }
	 @Override
	 public void startNewOrder(int time, Day day, String customerName, int customerAge) { //
	        Customer customer = new Customer(customerName, customerAge);
	        Order order = new Order(time, day, customer);
	        orderList.add(order);
	        alcoholOrderCount = 0;
	        currentIndex = orderList.indexOf(order);
	    }
	 @Override
	 public void processCoffeeOrder(String bevName, Size size, boolean extraShot, boolean extraSyrup) {
			orderList.get(currentIndex).addNewBeverage(bevName, size, extraShot, extraSyrup);
		}
	 
	 @Override
		public void processAlcoholOrder(String bevName, Size size) {
			orderList.get(currentIndex).addNewBeverage(bevName, size);
			alcoholOrderCount++;
		}
	 
	 @Override
		public void processSmoothieOrder(String bevName, Size size, int numOfFruits, boolean addProtien) {
			orderList.get(currentIndex).addNewBeverage(bevName, size, numOfFruits, addProtien);
		}
	 
	 @Override
		public int findOrder(int orderNo) {
			int ind = 0;
			while (ind < orderList.size()) {
				if (orderList.get(ind).getOrderNo() == orderNo)
					return ind;
	            ind++;
			}
			return -1;
		}
	 
	 @Override
		public double totalOrderPrice(int orderNo) {
			double total = 0.0;
			for (Order order : orderList) {
				if (order.getOrderNo() == orderNo) {
					for(Beverage beverage : order.getBeverages()) {
						total += beverage.calcPrice();
					}
				}
			}
			return total;
		}
	 @Override
		public double totalMonthlySale() {
			double total = 0;
			for (Order order : orderList) {
				for (Beverage beverage : order.getBeverages()) {
					total += beverage.calcPrice();
				}
		}
			return total;
		}
	 ////////////////
	 @Override
	 public int totalNumOfMonthlyOrders() {
			return orderList.size();
		}
	 
	 public Order getCurrentOrder() {
	        return orderList.get(currentIndex);
	    }
           
	 @Override
		public Order getOrderAtIndex(int index) {
			return orderList.get(index);
		}
	 
	 
	 @Override
		public void sortOrders() {
		
			for (int i = 0; i < orderList.size() - 1; i++) {
				int idx = i;
				int x = i+1;
				while(x < orderList.size()) {
					if( orderList.get(idx).getOrderNo() > orderList.get(x).getOrderNo()) {
					idx = x;
					x++;		
				}
				}
				Order order = orderList.get(idx);
				orderList.set(idx, orderList.get(i));
				orderList.set(i, order);
			}
			
		}
	 
	 public String toString() {
	        String s = "Monthly Orders\n";

	        for (Order o : orderList) {
	            s += o.toString();
	        }
	        s += "Total Sale: " + totalMonthlySale();

	        return s;
	    }


	


	


	


	


	
}
	 
	 
	


