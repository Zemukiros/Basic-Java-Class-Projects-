package ass;


/*
 * Class: CMSC203 
 * Instructor: 
 * Description: (Give a brief description for each Class)
 * Due: 5/3/2024
 * Platform/compiler: elips
 * I pledge that I have completed the programming  
 * assignment independently. I have not copied the code 
 * from a student or any source. I have not given my code 
 * to any student.
   Print your Name here: __Zemariam K   haftegebriel________
*/
public class BevShopDriverApp  {

	public static void main(String[] args) {

		int tempAge, tempOrderNo;

		Customer tempCustomer;
		int anInvalidTime = 8, anotherInvalidTime = 24;

		BevShop b = new BevShop();
		
		if ( !b.isValidTime(anInvalidTime))
			System.out.println( "Failed the test for invalid time!!"); 
		 
		if ( b.isValidTime(anotherInvalidTime))
			System.out.println( "Failed the test for invalid time!!");  
		
		System.out.println("The current order in process can have at most "+b.getMaxOrderForAlcohol()+" Alcoholic beverages"); // 3
		System.out.println("The minimum age to order alcohol drink is " +b.getMinAgeForAlcohol()); // 21
		System.out.println("Start please a new order"); // Start a new order
		b.startNewOrder(12, Day.MONDAY, "John", 23);

		System.out.println("Total on the Order:" + b.getCurrentOrder().calcOrderTotal()); // 0.0

		tempCustomer = b.getCurrentOrder().getCustomer();

		tempCustomer.setName("kim");
		tempCustomer.setAge(10);

		System.out.println("Would you please enter your name  "+ b.getCurrentOrder().getCustomer().getName()); // John
		System.out.println("Would you please enter your age  " +b.getCurrentOrder().getCustomer().getAge()); // 23

		tempAge = b.getCurrentOrder().getCustomer().getAge();
		System.out.println( "Your age is above 20 and you are eligible to order alcohol " + b.isValidAge(tempAge)); // true
		if (b.isValidAge(tempAge)) {
			System.out.println("Would you please add alcohol drink"); // Add alcohol drink

			b.processAlcoholOrder("Mohito", Size.SMALL);
		}

		System.out.println("The current order of drinks is "+ b.getNumOfAlcoholDrink()); // 1
		System.out.println("the Total price on the Order:" + b.getCurrentOrder().calcOrderTotal()); // 2.0
		System.out.println(b.isEligibleForMore()); // true

		System.out.println("woud you please add a second alcohol drink"); // Add second alcohol
														// drink
		//
		b.processAlcoholOrder("tonic", Size.LARGE);
		System.out.println( " The current order of drinks is "+ b.getNumOfAlcoholDrink()); // 2
		System.out.println("The Total Price on the Order:" + b.getCurrentOrder().calcOrderTotal()); // 6.0

		System.out.println("Add third alcohol drink"); // Add third alcohol
														// drink
		b.processAlcoholOrder("wine", Size.SMALL);

		System.out.println("the current order of drinks is "+b.getNumOfAlcoholDrink()); // 3
		
		System.out.println("The Total price on the Order:" + b.getCurrentOrder().calcOrderTotal()); // 8.0


		if (!b.isEligibleForMore())
			System.out.println("You have a maximum alcohol drinks for this order"); 

		System.out.println("Would you please add a COFFEE to your order: "); // Add a COFFEE to order
		b.processCoffeeOrder("cappuchino", Size.SMALL, true, true);
		System.out.println(" Total items on your order is  "+b.getNumOfAlcoholDrink()); // 4

		System.out.println("The Total Price on the Order:" + b.getCurrentOrder().calcOrderTotal()); // 11.0
		tempOrderNo = b.getCurrentOrder().getOrderNo();
		
		System.out.println("#-------------------------#");

		System.out.println("Would you please Start a new order"); // Start a new order

		b.startNewOrder(10, Day.SUNDAY, "Ray", 18);
		System.out.println("Would you please enter your name:"+ b.getCurrentOrder().getCustomer().getName()); // Ray
		System.out.println("Would you please enter your age: " +b.getCurrentOrder().getCustomer().getAge());
		

		System.out.println("The Total Price on the Order:" + b.getCurrentOrder().calcOrderTotal()); // 0.0
		System.out.println("Would you please add a SMOOTHIE to order"); // Add a SMOOTHIE to
														// order
		b.processSmoothieOrder("Morning Boost", Size.LARGE, 2, true);
		System.out.println("The Total Price on the Order:" + b.getCurrentOrder().calcOrderTotal()); // 6.5
		System.out.println("Would you please add a SMOOTHIE to order");
		System.out.println("Would you please add a COFFEE to order");
		b.processCoffeeOrder("Latte", Size.MEDIUM, false, false);
		System.out.println("The Total Price on the Order:" + b.getCurrentOrder().calcOrderTotal()); // 9.5
		if (b.isValidAge(b.getCurrentOrder().getCustomer().getAge())) {
			System.out.println("Should not get to here!!!");
			b.processAlcoholOrder("mohito", Size.MEDIUM);
		} else
			System.out.println("Your Age is not appropriate for alcohol drink!!");  

		tempOrderNo = b.getCurrentOrder().getOrderNo();

		if (b.findOrder(tempOrderNo) != -1)
			System.out.println("The Total price on the Order: " + b.totalOrderPrice(tempOrderNo)); // 9.5
		else {
			System.out.println("Order not found. Should no get to here!!");
		}

		int numOfFruits = 6;
		if (b.isMaxFruit(numOfFruits)) {
			// Maximum number of fruits
			System.out.println("You reached a Maximum number of fruits"); 
		}
		numOfFruits = 5;
		System.out.println("The total number of fruits is " + numOfFruits );
		

		b.processSmoothieOrder("zemu", Size.LARGE, numOfFruits, false);
		System.out.println("Total price on the second Order: " + b.getCurrentOrder().calcOrderTotal()); // 16.0
		System.out.println("Total amount for all Orders:" + b.totalMonthlySale()); // 27.0
		}

}