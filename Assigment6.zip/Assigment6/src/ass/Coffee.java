package ass;
/*
 * Class: CMSC203 
 * Instructor: 
 * Description: (Give a brief description for each Class)
 * Due: 5/3/2024
 * Platform/compiler: elips
 * I pledge that I have completed the programming  
 * assignment independently. I have not copied the code 
 * from a student or any source. I have not given my code 
 * to any student.
   Print your Name here: __Zemariam K   haftegebriel________
*/
public class Coffee extends Beverage {
	private boolean hasExtraShot;
    private final double SHOT_PRICE = 0.5;
    private boolean hasExtraSyrup;
    private final double SYRUP_PRICE = 0.5;
    
    public Coffee(String name, Size size, boolean extraShot, boolean extraSyrup) {
        super(name, Type.COFFEE, size);
        hasExtraShot = extraShot;
        hasExtraSyrup = extraSyrup;
    } 
    
    public boolean hasExtraShot() {
        return hasExtraShot;
    }

    public void setExtraShot(boolean extraShot) {
        hasExtraShot = extraShot;
    }

    public boolean hasExtraSyrup() {
        return hasExtraSyrup;
    }

    public void setExtraSyrup(boolean extraSyrup) {
        hasExtraSyrup = extraSyrup;
    }

    public double getShotPrice() {
        return SHOT_PRICE;
    }

    public double getSyrupPrice() {
        return SYRUP_PRICE;
    }
       
    public String toString() {
        double price = 0.0;
        String str = "" + getBevName() + ", " + getSize();

        if (hasExtraShot) {
            str += ", extra shot";
            if (hasExtraSyrup) {
                str += ", extra syrup";
            }
            price = calcPrice();
            str += ", price: $" + price;
            return str;
        }

        if (hasExtraSyrup) {
            str += ", extra syrup";
        }

        price = calcPrice();
        str += ", price: $" + price;
        return str;
    }
    
    
    public double calcPrice() {
        double price = super.getBasePrice();

        if (super.getSize() == Size.MEDIUM) {
            price += super.getSizeUp();
        } else if (super.getSize() == Size.LARGE) {
            price += 2 * super.getSizeUp();
        }

        if (hasExtraShot) {
            price += SHOT_PRICE;
        }

        if (hasExtraSyrup) {
            price += SYRUP_PRICE;
        }

        return price;
    }

    
    public boolean equals(Coffee c) {
        boolean baseEquals = super.equals(c);
        if (baseEquals) {
            return hasExtraShot == c.hasExtraShot() && hasExtraSyrup == c.hasExtraSyrup();
        }
        return false;
    }

}
